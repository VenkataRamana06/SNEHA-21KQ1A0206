Python 3.11.9 (tags/v3.11.9:de54cf5, Apr  2 2024, 10:12:12) [MSC v.1938 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
======= RESTART: C:\Users\POOJITHA\AppData\Local\Programs\Python\Python311\proj\data3.py ======
20
enter student name:pooji
enter roll number:201
enter marks:3 7 1
enter student name:janu
enter roll number:202
enter marks:6 4 2
enter student name:bhavana
enter roll number:203
enter marks:6 2 8
enter student name:anju
enter roll number:204
enter marks:7 2 8
enter student name:sneha
enter roll number:206
enter marks:7 2 2
enter student name:siri
enter roll number:207
enter marks:7 5 6
enter student name:akshay
enter roll number:208
enter marks:2 6 6
enter student name:sruth
enter roll number:209
enter marks:2 3 3
enter student name:ram
enter roll number:210
enter marks:7 4 3
enter student name:thiru
enter roll number:211
enter marks:6 6 7
enter student name:jaya
enter roll number:212
enter marks:5 5 6
enter student name:navya
enter roll number:213
enter marks:6 6 8
enter student name:triv
enter roll number:215
enter marks:4 4 6
enter student name:hema
enter roll number:218
enter marks:6 5 6
enter student name:nv
enter roll number:216
enter marks:2 7 8
enter student name:deep
enter roll number:217
enter marks:4 4 6
enter student name:kama
enter roll number:218
enter marks:6 4 4 
enter student name:merit
enter roll number:219
enter marks:7 6 5
enter student name:naga
enter roll number:220
enter marks:7 7 6
enter student name:hem
enter roll number:221
enter marks:5 6 7
       name  rollnumber      marks  total
0     pooji         201  [3, 7, 1]     11
1      janu         202  [6, 4, 2]     12
2   bhavana         203  [6, 2, 8]     16
3      anju         204  [7, 2, 8]     17
4     sneha         206  [7, 2, 2]     11
5      siri         207  [7, 5, 6]     18
6    akshay         208  [2, 6, 6]     14
7     sruth         209  [2, 3, 3]      8
8       ram         210  [7, 4, 3]     14
9     thiru         211  [6, 6, 7]     19
10     jaya         212  [5, 5, 6]     16
11    navya         213  [6, 6, 8]     20
12     triv         215  [4, 4, 6]     14
13     hema         218  [6, 5, 6]     17
14       nv         216  [2, 7, 8]     17
15     deep         217  [4, 4, 6]     14
16     kama         218  [6, 4, 4]     14
17    merit         219  [7, 6, 5]     18
18     naga         220  [7, 7, 6]     20
19      hem         221  [5, 6, 7]     18
max total=: 20
min total=: 8
sort total=: [8, 11, 11, 12, 14, 14, 14, 14, 14, 16, 16, 17, 17, 17, 18, 18, 18, 19, 20, 20]
{8, 11, 12, 14, 16, 17, 18, 19, 20}
maximum score of student1: 7
minimum score of student1: 1
total score of student1: 11
average score of student1: 3.6666666666666665
sort of all marks 1: [1, 3, 7]
score of each subject without duplicates: {1, 3, 7}
maximum score of student2: 6
minimum score of student2: 2
total score of student2: 12
average score of student2: 4.0
sort of all marks 2: [2, 4, 6]
score of each subject without duplicates: {2, 4, 6}
maximum score of student3: 8
minimum score of student3: 2
total score of student3: 16
average score of student3: 5.333333333333333
sort of all marks 3: [2, 6, 8]
score of each subject without duplicates: {8, 2, 6}
maximum score of student4: 8
minimum score of student4: 2
total score of student4: 17
average score of student4: 5.666666666666667
sort of all marks 4: [2, 7, 8]
score of each subject without duplicates: {8, 2, 7}
maximum score of student5: 7
minimum score of student5: 2
total score of student5: 11
average score of student5: 3.6666666666666665
sort of all marks 5: [2, 2, 7]
score of each subject without duplicates: {2, 7}
maximum score of student6: 7
minimum score of student6: 5
total score of student6: 18
average score of student6: 6.0
sort of all marks 6: [5, 6, 7]
score of each subject without duplicates: {5, 6, 7}
maximum score of student7: 6
minimum score of student7: 2
total score of student7: 14
average score of student7: 4.666666666666667
sort of all marks 7: [2, 6, 6]
score of each subject without duplicates: {2, 6}
maximum score of student8: 3
minimum score of student8: 2
total score of student8: 8
average score of student8: 2.6666666666666665
sort of all marks 8: [2, 3, 3]
score of each subject without duplicates: {2, 3}
maximum score of student9: 7
minimum score of student9: 3
total score of student9: 14
average score of student9: 4.666666666666667
sort of all marks 9: [3, 4, 7]
score of each subject without duplicates: {3, 4, 7}
maximum score of student10: 7
minimum score of student10: 6
total score of student10: 19
average score of student10: 6.333333333333333
sort of all marks 10: [6, 6, 7]
score of each subject without duplicates: {6, 7}
maximum score of student11: 6
minimum score of student11: 5
total score of student11: 16
average score of student11: 5.333333333333333
sort of all marks 11: [5, 5, 6]
score of each subject without duplicates: {5, 6}
maximum score of student12: 8
minimum score of student12: 6
total score of student12: 20
average score of student12: 6.666666666666667
sort of all marks 12: [6, 6, 8]
score of each subject without duplicates: {8, 6}
maximum score of student13: 6
minimum score of student13: 4
total score of student13: 14
average score of student13: 4.666666666666667
sort of all marks 13: [4, 4, 6]
score of each subject without duplicates: {4, 6}
maximum score of student14: 6
minimum score of student14: 5
total score of student14: 17
average score of student14: 5.666666666666667
sort of all marks 14: [5, 6, 6]
score of each subject without duplicates: {5, 6}
maximum score of student15: 8
minimum score of student15: 2
total score of student15: 17
average score of student15: 5.666666666666667
sort of all marks 15: [2, 7, 8]
score of each subject without duplicates: {8, 2, 7}
maximum score of student16: 6
minimum score of student16: 4
total score of student16: 14
average score of student16: 4.666666666666667
sort of all marks 16: [4, 4, 6]
score of each subject without duplicates: {4, 6}
maximum score of student17: 6
minimum score of student17: 4
total score of student17: 14
average score of student17: 4.666666666666667
sort of all marks 17: [4, 4, 6]
score of each subject without duplicates: {4, 6}
maximum score of student18: 7
minimum score of student18: 5
total score of student18: 18
average score of student18: 6.0
sort of all marks 18: [5, 6, 7]
score of each subject without duplicates: {5, 6, 7}
maximum score of student19: 7
minimum score of student19: 6
total score of student19: 20
average score of student19: 6.666666666666667
sort of all marks 19: [6, 7, 7]
score of each subject without duplicates: {6, 7}
maximum score of student20: 7
minimum score of student20: 5
total score of student20: 18
average score of student20: 6.0
sort of all marks 20: [5, 6, 7]
score of each subject without duplicates: {5, 6, 7}
maximum marks in subject 1: 6
maximum marks in subject 2: 7
maximum marks in subject 3: 8
